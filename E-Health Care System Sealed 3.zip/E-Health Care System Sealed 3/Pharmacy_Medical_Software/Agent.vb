﻿Imports System.Data.SqlClient
Public Class Agent
    Dim con As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=PharmacyDb;Integrated Security=True;Pooling=False")

    Private Sub Agent_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Populate() 'This is a Function()

    End Sub

    Public Sub Populate()  'This is a Function()

        con.Open()
        Dim sql = "Select * From EmployeeTbl"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        con.Close()

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        If EmpIdTb.Text = "" Then
            MessageBox.Show("Fill missing Data", "Missing Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Try

                'This connection is for the insert button
                con.Open()
                Dim query As String
                query = "insert into EmployeeTbl values('" & EmpIdTb.Text & "','" & EmpNameTb.Text & "','" & EmpSalaryTb.Text & "','" & EmpAgeTb.Text & "','" & EmpPhoneTb.Text & "','" & PasswordTb.Text & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Employee Added Succesfully", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)
                con.Close()
                Populate()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If

    End Sub


    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click

        Try

            If EmpIdTb.Text = "" Or EmpNameTb.Text = "" Or EmpSalaryTb.Text = "" Then
                MessageBox.Show("Please Fill in the Missing Information", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Else
                Try

                    con.Open()
                    Dim query As String
                    query = "Update EmployeeTbl set Empid= '" & EmpIdTb.Text & "',EmpName='" & EmpNameTb.Text & "',EmpSalary='" & EmpSalaryTb.Text & "',EmpAge='" & EmpAgeTb.Text & "',EmpPhone='" & EmpPhoneTb.Text & "',EmpPassword='" & PasswordTb.Text & "' Where Empid=" & EmpIdTb.Text & ""
                    Dim cmd As New SqlCommand(query, con)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Agent Updated SuccessFully", "Update Agent", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    con.Close()
                    Populate()

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            End If

        Catch ex As Exception

            MessageBox.Show("You Cannot Have Duplicate Keys", "Try different Value", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub


    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click

        Try

            If EmpIdTb.Text = "" Then
                MessageBox.Show("No Agent Selected")
            Else
                con.Open()
                Dim query As String
                query = "Delete from EmployeeTbl Where Empid =" & EmpIdTb.Text & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Employee SuccessFully Deleted")
                con.Close()
                Populate()

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click

        Me.Hide()
        Dim Home = New Home
        Home.Show()

    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Hide()
        Dim back = New Home
        back.Show()

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

        Application.Exit()

    End Sub

End Class