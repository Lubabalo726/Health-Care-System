﻿Public Class LoginForm

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click

        'LOGIN CODE

        If TxtUsername.Text = "" Or TxtPassword.Text = "" Then
            MessageBox.Show("Incorrect Password Or Username", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        ElseIf TxtUsername.Text = "Admin" And TxtPassword.Text = "1234" Then

            MessageBox.Show("Access Granted", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information)

            'Displays Home Table
            Me.Hide()
            Dim Home = New Home
            Home.Show()
        Else

            MessageBox.Show("Wrong Password Or Username", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            TxtUsername.Text = ""
            TxtPassword.Text = ""

        End If

    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        'CLEAN THE TEXTBOXES CODE

        TxtUsername.Text = ""
        TxtPassword.Text = ""

    End Sub

    Private Sub ChkPassword_CheckedChanged(sender As Object, e As EventArgs) Handles ChkPassword.CheckedChanged

        'MORE APPLICATION ADVANCING FEATURES FOR LOGIN

        If TxtPassword.UseSystemPasswordChar = True Then

            'Shows Password
            TxtPassword.UseSystemPasswordChar = False
        Else
            'Hide password
            TxtPassword.UseSystemPasswordChar = True
        End If


        'MORE APPLICATION ADVANCING FEATURES FOR LOGIN

        If TxtUsername.UseSystemPasswordChar = True Then

            'Shows Password
            TxtUsername.UseSystemPasswordChar = False
        Else
            'Hide password
            TxtUsername.UseSystemPasswordChar = True

        End If

    End Sub

   
    Private Sub LblExit_Click(sender As Object, e As EventArgs) Handles LblExit.Click

        Application.Exit()

    End Sub

End Class