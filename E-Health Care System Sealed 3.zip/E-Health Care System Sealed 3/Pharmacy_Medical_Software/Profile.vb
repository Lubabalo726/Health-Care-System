﻿Public Class Profile

    Private Sub Label4_Click(sender As Object, e As EventArgs)

        Application.Exit()

    End Sub


    Private Sub lblback_Click(sender As Object, e As EventArgs) Handles lblback.Click

        Me.Hide()
        Dim Home = New Home
        Home.Show()

    End Sub
End Class