﻿Imports System.Data.SqlClient
Public Class Billing
    Dim con As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=PharmacyDb;Integrated Security=True;Pooling=False")
    Dim Bitmap As Bitmap

    Private Sub FillCombo()

        con.Open()
        Dim cmd As New SqlCommand("Select * From MedicineTbl", con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim table As New DataTable
        adapter.Fill(table)
        MedComboCb.DataSource = table
        MedComboCb.DisplayMember = "MedName"
        MedComboCb.ValueMember = "MedName"

        con.Close()
    End Sub

    Dim stock, Uprice
    Private Sub fetchQuantity()

        con.Open()

        Dim cmd As New SqlCommand()
        Dim query = "Select * from MedicineTbl where MedName ='" & MedComboCb.SelectedValue.ToString() & "'"
        Dim command As New SqlCommand(query, con)
        Dim Dt As New DataTable
        Dim reader As SqlDataReader
        reader = command.ExecuteReader()
        While reader.Read

            'MessageBox.Show("" + reader(0).ToString())

            stock = reader(3)
            Uprice = reader(2)
            InStocklbl.Text = "Stock: " + reader(3).ToString()

        End While

        con.Close()

    End Sub

    Private Sub Billing_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FillCombo()

    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Hide()
        Dim back = New Home
        back.Show()

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.Exit()
    End Sub

    Private Sub MedComboCb_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles MedComboCb.SelectionChangeCommitted

        fetchQuantity()

    End Sub
    Dim i = 0, Totalprice
    Dim Grtotal = 0
    Private Sub BtnAddToBill_Click(sender As Object, e As EventArgs) Handles BtnAddToBill.Click

        Try

            If QuantityTb.Text > stock Then

                MessageBox.Show("Not Enough In-Stock", "Add Stock", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf QuantityTb.Text = "" Then
                MessageBox.Show("Enter a Quantity", "Enter Quantity", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                'Adding med to Bill

                Dim RowNum As Integer = DataGridView1.Rows.Add()
                i = i + 1
                DataGridView1.Rows.Item(RowNum).Cells("Column1").Value = i
                DataGridView1.Rows.Item(RowNum).Cells("Column2").Value = MedComboCb.SelectedValue.ToString()
                DataGridView1.Rows.Item(RowNum).Cells("Column3").Value = QuantityTb.Text
                DataGridView1.Rows.Item(RowNum).Cells("Column4").Value = Uprice
                DataGridView1.Rows.Item(RowNum).Cells("Column5").Value = QuantityTb.Text * Uprice

                Dim sutot = QuantityTb.Text * Uprice
                Grtotal = Grtotal + sutot
                LblTotal.Text = Grtotal
            End If

        Catch ex As Exception

            MessageBox.Show("Select A Medicine and Add its Stock", "Add Stock", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End Try
      
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click

        Try

            Dim height As Integer = DataGridView1.Height
            DataGridView1.Height = DataGridView1.RowCount * DataGridView1.RowTemplate.Height
            Bitmap = New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
            DataGridView1.DrawToBitmap(Bitmap, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
            PrintPreviewDialog1.ShowDialog()
            DataGridView1.Height = height

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Try
            e.Graphics.DrawImage(Bitmap, 0, 0)
            Dim RecP As RectangleF = e.PageSettings.PrintableArea

            If Me.DataGridView1.Height - RecP.Height > 0 Then
                e.HasMorePages = True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        Try

            PrintPreviewDialog1.Show()

        Catch ex As Exception
            MessageBox.Show("To PrintPreview Again Please Restart the Print Program", "Restart Program", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try

    End Sub
End Class