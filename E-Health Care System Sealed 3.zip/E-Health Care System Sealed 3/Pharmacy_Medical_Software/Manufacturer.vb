﻿Imports System.Data.SqlClient
Public Class Manufacturer

    Dim con As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=PharmacyDb;Integrated Security=True;Pooling=False")

    Private Sub FillComb()

        con.Open()
        Dim cmd As New SqlCommand("Select * From CompanyTbl", con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim table As New DataTable()
        adapter.Fill(table)
        con.Close()

    End Sub

    Public Sub Populate()

        con.Open()
        Dim sql = "Select * From CompanyTbl"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        con.Close()

    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        Try

            'This connection is for the insert button
            con.Open()
            Dim query As String
            query = "insert into CompanyTbl values('" & CompidTb.Text & "','" & CompNameTb.Text & "','" & PhoneNumTb.Text & "','" & AddressTb.Text & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Manufacturer Added Succesfully", "Add Manufacturer", MessageBoxButtons.OK, MessageBoxIcon.Information)
            con.Close()
            Populate()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Manufacturer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
        FillComb()

    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click

        If CompidTb.Text = "" Or CompNameTb.Text = "" Or PhoneNumTb.Text = "" Then
            MessageBox.Show("Please Fill in the Missing Information", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Try

                con.Open()
                Dim query As String
                query = "Update CompanyTbl set Compid= '" & CompidTb.Text & "', CompName='" & CompNameTb.Text & "',CompPhone='" & PhoneNumTb.Text & "',CompAddress='" & AddressTb.Text & "' Where Compid=" & CompidTb.Text & ""
                Dim cmd As New SqlCommand(query, con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Manufacturer Updated SuccessFully", "Update Manufacturer", MessageBoxButtons.OK, MessageBoxIcon.Information)
                con.Close()
                Populate()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If

    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click

        Try

            If CompidTb.Text = "" Then
                MessageBox.Show("No Company Selected")
            Else
                con.Open()
                Dim query As String
                query = "Delete from CompanyTbl Where Compid =" & CompidTb.Text & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Manufacturer SuccessFully Deleted")
                con.Close()
                Populate()

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub


    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

        Application.Exit()

    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Hide()
        Dim back = New Home
        back.Show()

    End Sub
End Class