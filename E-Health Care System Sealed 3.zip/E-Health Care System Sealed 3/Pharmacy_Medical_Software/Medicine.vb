﻿Imports System.Data.SqlClient
Public Class Medicine
    Dim con As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=PharmacyDb;Integrated Security=True;Pooling=False")

    'I Created the function to make things easier for Myself

    Private Sub FillComb()

        con.Open()
        Dim cmd As New SqlCommand("Select * From CompanyTbl", con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim table As New DataTable()
        adapter.Fill(table)
        con.Close()

    End Sub

    Public Sub Populate()

        con.Open()
        Dim sql = "Select * From MedicineTbl"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        MedicineGridView.DataSource = ds.Tables(0)
        con.Close()

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        Try

            'This connection is for the insert button
            con.Open()
            Dim query As String
            query = "insert into MedicineTbl values('" & MedicineTb.Text & "'," & BuyPriceTb.Text & ", " & SellPriceTb.Text & ", " & QuantityTb.Text & ",'" & ExpDate.Text & "','" & CompCb.SelectedItem.ToString() & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Medicine Added Succesfully", "Add Medicine", MessageBoxButtons.OK, MessageBoxIcon.Information)
            con.Close()
            Populate()

        Catch ex As Exception
            MessageBox.Show("Fill in Missing Data ", "Add Data", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try

    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles BtnUpdate.Click

        Try

            If MedicineTb.Text = "" Or BuyPriceTb.Text = "" Or SellPriceTb.Text = "" Or QuantityTb.Text = "" Then

                MessageBox.Show("Fill Missing Data", "Cannot Update", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else
                Try

                    con.Open()
                    Dim cmd As New SqlCommand("Update MedicineTbl set BuyPrice = " & BuyPriceTb.Text & ", SellPrice =" & SellPriceTb.Text & ", MedQuantity=" & QuantityTb.Text & ",EmpDate='" & ExpDate.Text & "', Company= '" & CompCb.SelectedItem.ToString() & "' Where MedName= '" & MedicineTb.Text & "' ", con)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Medicine Updated SuccessFully", "Update Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    con.Close()
                    Populate()

                Catch ex As Exception
                    MessageBox.Show("Cannot Update, Fill In Missing data", "Add Data", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click

        Try

            If MedicineTb.Text = "" Then
                MessageBox.Show("No Medicine Selected", "Select Medicine", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                con.Open()
                Dim query As String
                query = "Delete from MedicineTbl where MedName ='" & MedicineTb.Text & "'"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Medicine Successfully Deleted", "Delete Medicine", MessageBoxButtons.OK, MessageBoxIcon.Information)
                con.Close()
                Populate()

            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try
       
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

        Application.Exit()

    End Sub


    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click

        Me.Hide()
        Dim Home = New Home
        Home.Show()

    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Hide()
        Dim back = New Home
        back.Show()

    End Sub

    Private Sub Medicine_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FillComb()
        Populate()

    End Sub
End Class